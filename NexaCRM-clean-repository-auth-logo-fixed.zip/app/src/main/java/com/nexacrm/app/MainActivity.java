package com.nexacrm.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.net.Uri;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private WebView webView;
    private String pendingSharedText = null;
    private String pendingAuthAccess = null;
    private String pendingAuthRefresh = null;
    private boolean pageReady = false;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                pageReady = true;
                deliverSharedTextIfReady();
                deliverAuthCallbackIfReady();
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url.startsWith("https://wa.me/") || url.startsWith("https://api.whatsapp.com/")) {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                    return true;
                }
                return false;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
        handleShareIntent(getIntent());
        handleAuthIntent(getIntent());
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleShareIntent(intent);
        handleAuthIntent(intent);
    }

    private void handleAuthIntent(Intent intent) {
        if (intent == null || intent.getData() == null) return;
        Uri uri = intent.getData();
        if (!"nexacrm".equals(uri.getScheme()) || !"auth-callback".equals(uri.getHost())) return;
        String fragment = uri.getFragment();
        String access = uri.getQueryParameter("access_token");
        String refresh = uri.getQueryParameter("refresh_token");
        if (fragment != null) {
            for (String part : fragment.split("&")) {
                String[] pair = part.split("=", 2);
                if (pair.length == 2) {
                    String key = Uri.decode(pair[0]);
                    String value = Uri.decode(pair[1]);
                    if ("access_token".equals(key)) access = value;
                    if ("refresh_token".equals(key)) refresh = value;
                }
            }
        }
        if (access != null && refresh != null) {
            pendingAuthAccess = access;
            pendingAuthRefresh = refresh;
            deliverAuthCallbackIfReady();
        }
    }

    private void deliverAuthCallbackIfReady() {
        if (!pageReady || pendingAuthAccess == null || pendingAuthRefresh == null || webView == null) return;
        final String a = pendingAuthAccess, r = pendingAuthRefresh;
        pendingAuthAccess = null;
        pendingAuthRefresh = null;
        webView.evaluateJavascript("if(typeof handleAuthCallback==='function'){handleAuthCallback(" + JSONObject.quote(a) + "," + JSONObject.quote(r) + ");}", null);
    }

    private void handleShareIntent(Intent intent) {
        if (intent == null || !Intent.ACTION_SEND.equals(intent.getAction())) return;
        String type = intent.getType();
        if (type != null && type.startsWith("text/")) {
            CharSequence shared = intent.getCharSequenceExtra(Intent.EXTRA_TEXT);
            if (shared != null) {
                pendingSharedText = shared.toString();
                deliverSharedTextIfReady();
            }
        }
    }

    private void deliverSharedTextIfReady() {
        if (!pageReady || pendingSharedText == null || webView == null) return;
        String value = pendingSharedText;
        pendingSharedText = null;
        webView.evaluateJavascript("if(typeof receiveSharedText==='function'){receiveSharedText(" + JSONObject.quote(value) + ");}", null);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
