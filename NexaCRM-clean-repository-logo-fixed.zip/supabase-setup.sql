-- Jalankan sekali di Supabase Dashboard > SQL Editor > New query.
create table if not exists public.nexa_crm_snapshots (
  user_id uuid primary key references auth.users(id) on delete cascade,
  payload jsonb not null default '{"customers":[],"activities":[]}'::jsonb,
  updated_at timestamptz not null default now()
);
alter table public.nexa_crm_snapshots enable row level security;
drop policy if exists "Users can read their own Nexa CRM snapshot" on public.nexa_crm_snapshots;
drop policy if exists "Users can insert their own Nexa CRM snapshot" on public.nexa_crm_snapshots;
drop policy if exists "Users can update their own Nexa CRM snapshot" on public.nexa_crm_snapshots;
create policy "Users can read their own Nexa CRM snapshot" on public.nexa_crm_snapshots for select to authenticated using (auth.uid() = user_id);
create policy "Users can insert their own Nexa CRM snapshot" on public.nexa_crm_snapshots for insert to authenticated with check (auth.uid() = user_id);
create policy "Users can update their own Nexa CRM snapshot" on public.nexa_crm_snapshots for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
grant select, insert, update on public.nexa_crm_snapshots to authenticated;
